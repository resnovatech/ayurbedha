<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('walk_by_patient_services', function (Blueprint $table) {
            $table->id();
            $table->bigInteger('walk_by_patient_id')->unsigned();
            $table->foreign('walk_by_patient_id')->references('id')->on('walk_by_patients');
            $table->string('name');
            $table->text('detail');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('walk_by_patient_services');
    }
};
